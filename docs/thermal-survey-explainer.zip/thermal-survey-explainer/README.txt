Thermal Survey Field Manual - static site

Open index.html in a browser (double-click works; no server needed).
Contents: index.html, data.js (real readings from the MySQL cache), shots/ (app screenshots).
Fonts load from Google Fonts when online; system fonts are used offline.
